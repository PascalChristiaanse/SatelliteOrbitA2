from enum import Enum

class Constants(Enum):
    c = 299792458.0  # [m/s], From assignment
    omg_e = 7.292115e-5  # [rad/s], From assignment