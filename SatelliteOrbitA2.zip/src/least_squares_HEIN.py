import numpy as np
import matplotlib
matplotlib.use("Qt5Agg")  # Change to an interactive backend
import matplotlib.pyplot as plt

from mpl_toolkits.mplot3d import Axes3D

t = np.loadtxt('./data/t.txt')  # epochs - s
CA_range = np.loadtxt('./data/CA_range.txt')  # pseudorange observations from CA code - km
PRN_ID = np.loadtxt('./data/PRN_ID.txt')  # PRN ID of tracked GPS satellites
clk_gps = np.loadtxt('./data/clk_gps.txt')  # clock correction for GPS sats - s

rx_gps = np.loadtxt('./data/rx_gps.txt')  # GPS satellite positions (transmitters) - km
ry_gps = np.loadtxt('./data/ry_gps.txt')
rz_gps = np.loadtxt('./data/rz_gps.txt')

vx_gps = np.loadtxt('./data/vx_gps.txt') # GPS satellite velocities (transmitters) - km/s
vy_gps = np.loadtxt('./data/vy_gps.txt')
vz_gps = np.loadtxt('./data/vz_gps.txt')

rx = np.loadtxt('./data/rx.txt')  # precise positions (receivers) - km
ry = np.loadtxt('./data/ry.txt')
rz = np.loadtxt('./data/rz.txt')


def correct_satellite_positions(sat_positions, sat_velocities, sat_clock_offsets):
    """
    Correct satellite positions for clock offsets.
    sat_positions: N x 3 array of satellite positions (x, y, z)
    sat_velocities: N x 3 array of satellite velocities (vx, vy, vz)
    sat_clock_offsets: N array of clock offsets in seconds
    """
    corrected_positions = sat_positions - (sat_velocities * sat_clock_offsets[:, np.newaxis])
    return corrected_positions


def correct_observations(observations, sat_clock_offsets, c=299792.458):
    """ Correct observations for satellite clock offsets """
    return observations + c * sat_clock_offsets

def build_covariance_matrix(num_obs, sigma, rho):
    """ Build the covariance matrix with standard deviation and correlation """
    C = np.eye(num_obs) * sigma**2
    for i in range(num_obs):
        for j in range(num_obs):
            if i != j:
                C[i, j] = rho * sigma**2
    return C

def build_H_matrix(sat_positions, receiver_pos):
    """ Build the H-matrix for pseudorange observations, no clock bias """
    H = []
    for sat_pos in sat_positions:
        dx = sat_pos[0] - receiver_pos[0]
        dy = sat_pos[1] - receiver_pos[1]
        dz = sat_pos[2] - receiver_pos[2]
        geometric_range = np.sqrt(dx**2 + dy**2 + dz**2)
        H.append([-dx / geometric_range, -dy / geometric_range, -dz / geometric_range, 299792.458])
        # print(H)
    return np.array(H)

def least_squares_iteration(observations, sat_positions, sat_velocities, sat_clock_offsets, initial_guess, sigma, rho, max_iter=100, tol=1e-8):
    """
    Solve for the receiver position using least squares without clock bias estimation.
    """
    sat_positions = correct_satellite_positions(sat_positions,sat_velocities,sat_clock_offsets)
    
    num_obs = len(observations)
    C = build_covariance_matrix(num_obs, sigma, rho)
    C_inv = np.linalg.inv(C)
    x = np.array(initial_guess, dtype=float)
    lambda_damping = 1e-6

    # Correct observations for satellite clock offsets
    corrected_obs = observations

    # print("Starting least squares without clock bias...")
    for i in range(max_iter):
        # Build H matrix
        H = build_H_matrix(sat_positions, x)
        print(H)
        break

        # Calculate predicted ranges
        predicted_ranges = np.linalg.norm(sat_positions - x[:3], axis=1)

        # Calculate residuals
        residuals = corrected_obs - predicted_ranges

        # Compute corrections using weighted least squares
        H_T_C_inv = H.T @ C_inv
        try:
            delta_x = np.linalg.inv(H_T_C_inv @ H) @ (H_T_C_inv @ residuals)

            #delta_x = np.linalg.inv(H_T_C_inv @ H + lambda_damping * np.eye(3)) @ (H_T_C_inv @ residuals)
        except np.linalg.LinAlgError:
            # print("Matrix is singular, increasing damping factor...")
            lambda_damping *= 10
            continue

        # Update solution
        x += delta_x

        # print(f"Iteration {i+1}: Correction = {delta_x}\n Residuals = {residuals}\n tol = {np.linalg.norm(delta_x)}")
        if np.linalg.norm(delta_x) < tol:
            print("Converged!")
            break
    else:
        print("Maximum iterations reached without convergence.")

    # print(f"Final solution: {x}\n real solution {initial_guess}")
    return x[:3]

if __name__ == "__main__":
    
    sols=[]
    
    for j in range(len(clk_gps)):
        # Observed pseudoranges
        observations=[]
        for n in CA_range[j]:
            if n!=0:
                observations.append(n)
        observations = np.array(observations)
    
        # Satellite positions
        sat_positions = []
        for i in range(len(rx_gps[j])):
            if rx_gps[j][i] != 0:
                sat_positions.append(np.array([rx_gps[j][i], ry_gps[j][i], rz_gps[j][i]]))
        sat_positions = np.array(sat_positions)
        
        sat_velocities = []
        for i in range(len(vx_gps[j])):
            if vx_gps[j][i] != 0:
                sat_velocities.append(np.array([vx_gps[j][i], vy_gps[j][i], vz_gps[j][i]]))
        sat_velocities = np.array(sat_velocities)
    
        # Satellite clock offsets
        #sat_clock_offsets = np.array(clk_gps[0][0:9])
        
        sat_clock_offsets=[]
        for n in clk_gps[j]:
            if n!=0:
                sat_clock_offsets.append(n)
        sat_clock_offsets = np.array(sat_clock_offsets)
    
        # Initial guess for [x, y, z]
        # initial_guess = [np.average(rx_gps[j]), np.average(ry_gps[j]),np.average(rz_gps[j]), 0]
        initial_guess = np.array([6374, 0, 0, 0.001])
        # initial_guess = [0, 0,0]
    
        # Measurement standard deviation and correlation
        sigma = 3/1000  # km
        rho = 0.2  # correlation
    
        # Run least-squares estimation
        final_solution = least_squares_iteration(
            observations, sat_positions,sat_velocities, sat_clock_offsets, initial_guess, sigma, rho
        )
        break
        sols.append(np.array(final_solution).tolist())
    
    
    x_components = [item[0] for item in sols]
    y_components = [item[1] for item in sols]
    z_components = [item[2] for item in sols]
    # print(sols)

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot the first set of coordinates
    ax.plot(x_components, y_components, z_components, c='blue', label='LSQ SOL')
    
    # Plot the second set of coordinates
    ax.plot(rx, ry, rz, c='red', label='true sol')
    
    # Add labels and legend
    ax.set_xlabel('X Axis')
    ax.set_ylabel('Y Axis')
    ax.set_zlabel('Z Axis')
    ax.set_title('3D Scatter Plot of Two Sets of Coordinates')
    ax.legend()
    
    # Show the plot
    plt.show()